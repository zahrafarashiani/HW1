 Hw1 -Internet Engineering course
 this is my first project for Internet Engineering course .in this project I took fallowing steps:
 1-I ran a webserver in node using using Express.
 
 2-I installed a package (library) named  point-in-polygon  to perform geo spatial functionality in order to given GPS
 coordinate and determine which polygons the points is inside them.
 
 3-then at third step I deployed this application on Heroku platform .
my heroku web link =https://node-js-hw1.herokuapp.com
 
 4-I tasted using a node js tool called artillery .
 test1:https://https://node-js-hw1.herokuapp.com/gis/testpoint?lat=52&long=34
 
 Started phase 0, duration: 1s @ 22:20:03(+0330) 2019-10-25
Report @ 22:20:09(+0330) 2019-10-25
Elapsed time: 6 seconds
  Scenarios launched:  10
  
  Scenarios completed: 10
  
  Requests completed:  200
  RPS sent: 31.4
  Request latency:
    min: 192.3
    max: 1125.2
    median: 201.7
    p95: 780.3
    p99: 1080.7
  Codes:
    200: 200

All virtual users finished
Summary report @ 22:20:09(+0330) 2019-10-25
  Scenarios launched:  10
  Scenarios completed: 10
  Requests completed:  200
  RPS sent: 31.25
  Request latency:
    min: 192.3
    max: 1125.2
    median: 201.7
    p95: 780.3
    p99: 1080.7
  Scenario counts:
    0: 10 (100%)
  Codes:
    200: 200
 
 
 
 
