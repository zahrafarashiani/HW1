const ff = require('fs');
const express = require('express');
 var dakhel = require('point-in-polygon');
const whiskers = require('whiskers') ;
const helper = require('./helper.js');
const port = 5000;
var y = [];
let result=[];
var data = ff.readFileSync('sample-data.json', 'utf-8');
var Gis = JSON.parse(data.toString());
const app=express(); 
app.use(express.json());
console.log('--------------------------- NEW APP ');
app.use(function(req,res,next){
  console.log('middlewere!');
  next(); 
});
app.get('/', (req, res) => {
 console.log('start!!!!')
  
});
Gis.features.forEach(function (feature) {
  y.push(feature);

});
//get 
app.get('/gis/testpoint',(req,res)=>{
   result =  [] ;

  var pt = [parseFloat(req.query.lat), parseFloat(req.query.long)];
  y.forEach(function (feature) {
     
      if (dakhel(pt, feature.geometry.coordinates[0]))
        result.push(feature.properties.name);
  })

  res.json(result);
    
  
   
})
    //put
    app.put('/gis/addpolygon',(req,res)=>{
      try {
        x.push(req.body);
        res.sendStatus(200); 

      } catch (err) {
        res.sendStatus(403); 
        helper.logger.error({
          message: err.message,
          query: req.query,
        });
  
      }
     } )
     app.listen(port,()=>{
        console.log(`listening port ${port}`)
    })
